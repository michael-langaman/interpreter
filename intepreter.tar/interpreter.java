import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Stack;
import java.util.HashMap; 
import java.util.LinkedList;
import java.util.Queue;
import java.util.Arrays;
import java.util.Collections;

public class interpreter {
    
    public static void error(Stack<Element> stack, Element a, Element b) {
        stack.push(b);
        stack.push(a);
        stack.push(new Element(":error:"));
    }

    public static void push(Stack<Element> stack, Element e, HashMap<String, Element> binds, boolean funCall) {
        if(e.equals("-0")) stack.push(new Element(0));
        else if(e.isStr() && isDub(e.getStrVal())) {
            stack.push(new Element(":error:"));
        } else if(funCall && e.isName()) {
            // System.out.println(Arrays.asList(binds));
            if(binds.containsKey(e.getName())) {
                Element unit = binds.get(e.getName());
                Element temp = null;
                //System.out.println(unit.getType());
                switch(unit.getType()) {
                    case "int":
                    temp = new Element(unit.getIntVal());
                    //System.out.println(e.getIntVal());
                    break;
                    case "string":
                    temp = new Element(unit.getStrVal());
                    break;
                    case "bool":
                    temp = new Element(unit.getBoolVal());
                    break;
                }
                if(temp != null) stack.push(temp);
            }
            else stack.push(e);
        } else {
            stack.push(e);
        }
    }
    
    public static void pop(Stack<Element> stack) {
        if(stack.empty()) {
            stack.push(new Element(":error:"));
        } else {
            stack.pop();
        }
    }

    public static void neg(Stack<Element> stack, HashMap<String, Element> binds) {
        if(stack.empty()) {
            stack.push(new Element(":error:"));
        } else {
            Element a = stack.pop();
            if(a.isInt()) {
                int num = a.getIntVal();
                num *= -1;
                Element result = new Element(num);
                stack.push(result);
            } else if(a.isName()) {
                if(binds.containsKey(a.getName())) {
                    Element e = binds.get(a.getName());
                    int val = e.getIntVal();
                    val *= -1;
                    Element result = new Element(val);
                    stack.push(result);
                }
            }
        }
    }
    
    public static void swap(Stack<Element> stack) {
        if(stack.size() < 2) {
            stack.push(new Element(":error:"));
            return;
        } else {
            Element a = stack.pop();
            Element b = stack.pop();
            stack.push(a);
            stack.push(b);
        }
    }

    public static void arith(Stack<Element> stack, String oper, Element a, Element b) {
        boolean dne = false;
        int ans = -1024;
        int x = a.getIntVal();
        int y = b.getIntVal();
        if(a.isUnit()) a = new Element(a.getName());
        if(b.isUnit()) b = new Element(b.getName());
        if(oper.equals("add")) ans = x + y;
        else if(oper.equals("sub")) ans = y - x;
        else if(oper.equals("mul")) ans = x * y;
        else if(oper.equals("div")) { 
            if(x == 0) {
                stack.push(b);
                stack.push(a);
                stack.push(new Element(":error:"));
                dne = true;
            } else { ans = y / x; }
        } else if(oper.equals("rem")) {
            if(x == 0) {
                stack.push(b);
                stack.push(a);
                stack.push(new Element(":error:"));
                dne = true;
            } else { ans = y % x; }
        } else if(oper.equals("equal")) {
            boolean result =  x == y;
            stack.push(new Element(result));
            return;
        } else if(oper.equals("lessThan")) {
            boolean result = y < x;
            stack.push(new Element(result));
            return;
        }
        Element result = new Element(ans);
        // System.out.println(result.printVal());
        if(!dne) stack.push(result);
    }

    public static void math(Stack<Element> stack, String oper, HashMap<String, Element> binds) {
        if(stack.size() < 2) stack.push(new Element(":error:"));
        else {
            Element a = stack.pop();
            Element b = stack.pop();
            // System.out.println("A: " + a.printVal() + " " + oper + " B: " + b.printVal());
            if(a.isUnit() || b.isUnit()) {
                // System.out.println("FUCK");
                error(stack, a, b);
            }
            else if(a.isInt() && b.isInt()) {
                arith(stack, oper, a, b);
            } else if(a.isName() && b.isName()) {
                Element c = search(a, binds);
                Element d = search(b, binds);
                if(binds.containsKey(a.getName()) && binds.containsKey(b.getName()) && c.isInt() && d.isInt()) {
                    arith(stack, oper, c, d);
                } else {
                    error(stack, a, b);
                }
            } else if(a.isName() && b.isInt()) {
                if(binds.containsKey(a.getName())) {
                    Element e = search(a, binds);
                    if(e.isInt()) arith(stack, oper, e, b);
                    else error(stack, a, b);
                } else {
                    error(stack, a, b);
                }
            } else if(a.isInt() && b.isName()) {
                if(binds.containsKey(b.getName())) {
                    Element e = search(b, binds);
                    if(e.isInt()) arith(stack, oper, a, e);
                    else {
                        error(stack, a, b);
                    }
                } else {
                    // System.out.print("FALCO");
                    error(stack, a, b);
                }
            } else {
                error(stack, a, b);
            }
        }
    }

    public static void boolHelper(Stack<Element> stack, String command, Element a, Element b) {
        boolean x = a.getBoolVal();
        boolean y = b.getBoolVal();
        boolean result = true;
        if(command.equals("and")) result = x && y;
        else result = x || y;
        stack.push(new Element(result));
    }   

    public static void bool(Stack<Element> stack, String command, HashMap<String, Element> binds) {
        if(stack.size() < 2) stack.push(new Element(":error:"));
        else {
            Element a = stack.pop();
            Element b = stack.pop();
            if(a.isBool() && b.isBool()) boolHelper(stack, command, a, b);
            else if(a.isName() && b.isName()) {
                if(binds.containsKey(a.getName()) && binds.containsKey(b.getName())) {
                    Element c = binds.get(a.getName());
                    Element d = binds.get(b.getName());
                    if(c.isBool() && d.isBool()) boolHelper(stack,command, c, d);
                    else error(stack, a, b);
                } else {
                    error(stack, a, b);
                }
            } else if(a.isBool() && b.isName()) {
                if(binds.containsKey(b.getName())) {
                    Element e = binds.get(b.getName());
                    if(e.isBool()) boolHelper(stack, command, a, e);
                    else error(stack, a, b);
                } else error(stack, a, b);
            } else if(a.isName() && b.isBool()) {
                if(binds.containsKey(a.getName())) {
                    Element e = binds.get(a.getName());
                    if(e.isBool()) boolHelper(stack, command, b, e);
                    else error(stack, a, b);
                } else error(stack, a, b);
            } else {
                error(stack, a, b);
            }
        }
    }

    public static void not(Stack<Element> stack, HashMap<String, Element> binds) {
        if(stack.empty()) stack.push(new Element(":error:"));
        else {
            Element a = stack.pop();
            if(a.isBool()) {
                boolean x = a.getBoolVal();
                boolean result = !x;
                stack.push(new Element(result));    
            } else if(a.isName()) {
                if(binds.containsKey(a.getName())) {
                    Element e = binds.get(a.getName());
                    if(e.isBool()) {
                        boolean x = e.getBoolVal();
                        boolean result = !x;
                        stack.push(new Element(result));
                    } else {
                        stack.push(a);
                        stack.push(new Element(":error:"));
                    }
                } else {
                    stack.push(a);
                    stack.push(new Element(":error:"));
                }
            } else {
                stack.push(a);
                stack.push(new Element(":error:"));
            }
        }
    }

    public static Element search(Element a, HashMap<String, Element> binds) {
        return binds.get(a.getName());
    }   

    public static void bind(Stack<Element> stack, HashMap<String, Element> binds) {
        if(stack.size() < 2) stack.push(new Element(":error:"));
        else {
            Element a = stack.pop();
            Element b = stack.pop();
            if(b.isName()) {
                String name = b.getName();
                String type = a.getType();
                Element result = null;
                switch(type) {
                case "string":
                    result = new Element(name, a.getStrVal());
                    break;
                case "int":
                    result = new Element(name, a.getIntVal());
                    break;
                case "bool":
                    result = new Element(name, a.getBoolVal());
                    break;
                case "name":
                    if(!binds.containsKey(a.getName())) error(stack, a, b);
                    else {
                        result = new Element(name, binds.get(a.getName()));
                    }
                    break;
                default: 
                    error(stack, a, b);
                    break;
                }
                if(result != null) {
                    binds.put(name, result);
                    stack.push(result);
                }
            } else {
                error(stack, a, b);
            }
        }
    }

    public static void if_(Stack<Element> stack, HashMap<String, Element> binds) {
        if(stack.size() < 3) stack.push(new Element(":error:"));
        else {
            Element a = stack.pop();
            Element b = stack.pop();
            Element c = stack.pop();
            // System.out.println("IF -> A: " + a.printVal() + " B : " + b.printVal() + " C: " + c.printVal());
            if(c.isBool()) {
                if(c.getBoolVal()) stack.push(a);
                else stack.push(b);
            } else if(c.isName()) {
                if(binds.containsKey(c.getName())) {
                    Element e = binds.get(c.getName());
                    if(e.isBool()) {
                        if(e.getBoolVal()) stack.push(a);
                        else stack.push(b);
                    } else error(stack, a, b);
                } else error(stack, a, b);
            } else {
                //System.out.println("FUK");
                stack.push(c);
                stack.push(b);
                stack.push(a);
                stack.push(new Element(":error:"));
            }
        }
    }

    public static Stack<Element> let(Stack<Element> stack, HashMap<String, Element> binds, Queue<String> lines, String outFile) {
        while(!lines.isEmpty()) {
            String line = lines.remove();
            String command = command(line);
            String value = value(line);
            Element e = element(value);
            if(command.equals("end")) {
                // printStack(stack);
                return stack;
            }
            else interpret(stack, binds, lines, command, e, outFile, true, true);
        }
        return stack;
    }

    public static void fun(String functionName, Element arg, Stack<Element> stack, HashMap<String, Element> binds, Queue<String> lines) {
        Queue<String> code = new LinkedList<String>();
        while(!lines.isEmpty()) {
            String line = lines.remove();
            if(line.equals("funEnd")) break;
            code.add(line);
        }
        HashMap<String, Element> temp = new HashMap<String, Element>(binds);
        // temp.put(arg.getName(), arg);
        Element function = new Element(functionName, arg, code, temp);
        binds.put(functionName, function);
        stack.push(function);
    }

    public static void setElem(Element a, Element b) {
        switch(b.getType()) {
            case "string":
            a = new Element(b.getStrVal());
            break;
            case "int":
            a = new Element(b.getIntVal());
            break;
            case "bool":
            a = new Element(b.getBoolVal());
            break;
        }
    } 

    public static Stack<Element> call(Element function, Element argument, Stack<Element> stack, HashMap<String, Element> binds, Queue<String> lines, String outFile, boolean local) {
        Queue<String> code = new LinkedList<String>(function.getCode());
        while(!code.isEmpty()) {
            String line = code.remove();
            String command = command(line);
            String value = value(line);
            Element e = null;
            if(value.equals(function.getArgumentName())) {
                e = argument;
            } else {
                e = element(value);
            }
            if(command.equals("return")) return stack;
            interpret(stack, binds, code, command, e, outFile, true, local);
        }
        return stack;
    }

    public static void inOutFun() {

    }

    public static LinkedList<String> getLines(String inFile) {
        LinkedList<String> lines = new LinkedList<String>();
        try {
            FileReader read = new FileReader(inFile);
            BufferedReader buffR = new BufferedReader(read);
            String line = null;
            while((line = buffR.readLine()) != null) {
                lines.add(line);
            }
            buffR.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return lines;
    }
    
    public static void writeOutput(Stack<Element> stack, String outFile) {
        BufferedWriter buffW = null;
        try {
            FileWriter write = new FileWriter(outFile);
            buffW = new BufferedWriter(write);
            int count = 0;
            while(!stack.empty()) {
                Element p = stack.pop();
                buffW.write(p.getOutput());
                buffW.newLine();
                ++count;
            }
            buffW.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static boolean isNum(String a) {
        try {
            Integer.parseInt(a);
            return true;
        } catch(NumberFormatException ex) {
            return false;
        }
    }

    public static boolean isDub(String a) {
        try {
            Double.parseDouble(a);
            return true;
        } catch(NumberFormatException ex) {
            return false;
        }
    }

    public static Element element(String value) {
        Element e = null;
        if(isNum(value)) {
            e = new Element(Integer.parseInt(value));
        } else {
            e = new Element(value);
        }
        return e;
    }

    public static String command(String line) {
        String[] s = line.split(" ");
        return s[0];
    }

    public static String value(String line) {
        String[] s = line.split(" ");   
        String value = "";
        if(s.length == 2) {
            value = s[1];
        } else if(s.length > 2) {
            value += s[1];
            for(int j = 2; j < s.length; ++j) {
                value = value + " " + s[j];
            }
        } else {}
        return value;
    }

    public static void printStack(Stack<Element> s) {
        Stack<Element> stack = new Stack<Element>();
        stack.addAll(s);
        String st = "";
        while(!stack.empty()) {
            Element a = stack.pop();
            st += a.printVal();
        }
        System.out.println(st + " | ");
    }

    public static void interpret(Stack<Element> stack, HashMap<String, Element> binds, Queue<String> lines, String command, Element e, String outFile, boolean local, boolean funCall) {
        // System.out.println(command + " - " + e.printVal());
        switch(command) {
            case "push":
                push(stack, e, binds, funCall);
                break;
            case "pop":
                pop(stack);
                break;
            case ":true:":
                stack.push(new Element(true));
                break;
            case ":false:":
                stack.push(new Element(false));
                break;
            case ":error:":
                stack.push(new Element(command));
                break;
            case "add":
                math(stack, command, binds);
                break;
            case "sub":
                math(stack, command, binds);
                break;
            case "mul":
                math(stack, command, binds);
                break;
            case "div":
                math(stack, command, binds);
                break;
            case "rem":
                math(stack, command, binds);
                break;
            case "neg":
                neg(stack, binds);
                break;
            case "swap":
                swap(stack);
                break;
            case "and":
                bool(stack, command, binds);
                break;
            case "or":
                bool(stack, command, binds);
                break;
            case "not":
                not(stack, binds);
                break;
            case "equal":
                math(stack, command, binds);
                break;
            case "lessThan":
                math(stack, command, binds);
                break;
            case "bind":
                bind(stack, binds);
                break;
            case "if":
                if_(stack, binds);
                break;
            case "let":
                Stack<Element> temp = new Stack<Element>();
                if(!local) {
                    HashMap<String, Element> tempBind = new HashMap<String, Element>();
                    Stack<Element> s = let(temp, tempBind, lines, outFile);
                    Element a = s.pop();
                    stack.push(a);
                } else {
                    Stack<Element> s = let(temp, binds, lines, outFile);
                    Element a = s.pop();
                    stack.push(a);
                }
                break;
            case "fun":
                String s = e.printVal();
                String[] values = s.split(" ");
                String functionName = values[0];
                String a = values[1];
                Element arg = new Element(a);
                fun(functionName, arg, stack, binds, lines);
                break;
            case "call":
                Element function = stack.pop();
                Element argument = stack.pop();
                String funName = function.getName();
                String argu = "";
                switch(argument.getType()) {
                    case "int":
                    argu = Integer.toString(argument.getIntVal());
                    break;
                    case "name":
                    argu = argument.getName();
                    break;
                }
                if(binds.containsKey(funName) && binds.get(funName).isFunction() && !argument.isError()) {
                    function = binds.get(funName);
                    if(argument.isName() && binds.containsKey(argument.getName())) {
                        Element ex = binds.get(argument.getName());
                        if(!ex.isFunction()) {
                            switch(ex.getType()) {
                                case "int":
                                argument = new Element(ex.getIntVal());
                                break;
                            }
                        }
                    } else {
                        function.addToEnv(function.getArgumentName(), argument);
                    }
                    HashMap<String, Element> env = function.getEnv();
                    // env.put(funName, function);
                    Stack<Element> funResult = null;
                    if(funCall || env.size() < 2) {
                        funResult = call(function, argument, new Stack<Element>(), binds, lines, outFile, funCall);
                    } else {
                        funResult = call(function, argument, new Stack<Element>(), env, lines, outFile, funCall);
                    }
                    Element top = funResult.pop();
                    // System.out.println(top.printVal());
                    stack.push(top);
                } else {
                    error(stack, function, argument);
                }
                break;
            case "quit":
                writeOutput(stack, outFile);
                break;
            }
    }

    public static void interpreter(String inFile, String outFile) {
        Stack<Element> stack = new Stack<Element>();
        HashMap<String, Element> binds = new HashMap<String, Element>();
        Queue<String> lines = getLines(inFile);
        while(!lines.isEmpty()) {
            String line = lines.remove();
            String command = command(line);
            String value = value(line);
            Element e = element(value);
            interpret(stack, binds, lines, command, e, outFile, false, false);
        }
    }
}